﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OwlBird : Bird
{
    public Sprite owl; // Drag your first sprite here
    public Sprite Red; // Drag your second sprite here
    public float _boom = 100;
    public bool _hasBoom = false;

    public void ChangeTheDamnSprite()
    {
        
        if (spriteRenderer.sprite == owl || spriteRenderer.sprite == null) // if the spriteRenderer sprite = sprite1 then change to sprite2
        {
            spriteRenderer.sprite = Red;
        }
        else
        {
            spriteRenderer.sprite = owl; // otherwise change it back to sprite1
        }
    }

    public override void Boom()
    {
        if (State == BirdState.Thrown || State == BirdState.HitSomething && !_hasBoom)
        {
            ChangeTheDamnSprite();
            float damage = gameObject.GetComponent<Rigidbody2D>().velocity.magnitude * 40;
            _hasBoom = true;
            StartCoroutine(DestroyAfter(0.2f));
        }
    }

}
